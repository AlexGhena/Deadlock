#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

pthread_mutex_t mutexA;
pthread_mutex_t mutexB;

void* thread_function_one(void* arg) {
    pthread_mutex_lock(&mutexA);
    pthread_mutex_lock(&mutexB);
    pthread_mutex_unlock(&mutexB);
    pthread_mutex_unlock(&mutexA);

    return NULL;
}

void* thread_function_two(void* arg) {
    pthread_mutex_lock(&mutexB);
    pthread_mutex_lock(&mutexA);
    pthread_mutex_unlock(&mutexA);
    pthread_mutex_unlock(&mutexB);

    return NULL;
}

int main() {
    pthread_mutex_init(&mutexA, NULL);
    pthread_mutex_init(&mutexB, NULL);

    pthread_t thread1, thread2;
    pthread_create(&thread1, NULL, thread_function_one, NULL);
    pthread_create(&thread2, NULL, thread_function_two, NULL);

    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    pthread_mutex_destroy(&mutexA);
    pthread_mutex_destroy(&mutexB);

    return 0;
}

