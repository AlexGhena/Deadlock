#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

pthread_mutex_t mutexA;
pthread_mutex_t mutexB;
pthread_mutex_t mutexC;
pthread_mutex_t mutexD;
pthread_mutex_t mutexE;

void* thread_function_one(void* arg) {
    pthread_mutex_lock(&mutexA);
    sleep(1);
    pthread_mutex_lock(&mutexB);
    // Deadlock aici
    pthread_mutex_unlock(&mutexB);
    pthread_mutex_unlock(&mutexA);
    return NULL;
}

void* thread_function_two(void* arg) {
    pthread_mutex_lock(&mutexB);
    sleep(1);
    pthread_mutex_lock(&mutexC);
    // Deadlock aici
    pthread_mutex_unlock(&mutexC);
    pthread_mutex_unlock(&mutexB);
    return NULL;
}

void* thread_function_three(void* arg) {
    pthread_mutex_lock(&mutexC);
    sleep(1);
    pthread_mutex_lock(&mutexD);
    // Deadlock aici
    pthread_mutex_unlock(&mutexD);
    pthread_mutex_unlock(&mutexC);
    return NULL;
}

void* thread_function_four(void* arg) {
    pthread_mutex_lock(&mutexD);
    sleep(1);
    pthread_mutex_lock(&mutexE);
    // Deadlock aici
    pthread_mutex_unlock(&mutexE);
    pthread_mutex_unlock(&mutexD);
    return NULL;
}

void* thread_function_five(void* arg) {
    pthread_mutex_lock(&mutexE);
    sleep(1);
    pthread_mutex_lock(&mutexA);
    // Deadlock aici
    pthread_mutex_unlock(&mutexA);
    pthread_mutex_unlock(&mutexE);
    return NULL;
}

int main() {
    pthread_mutex_init(&mutexA, NULL);
    pthread_mutex_init(&mutexB, NULL);
    pthread_mutex_init(&mutexC, NULL);
    pthread_mutex_init(&mutexD, NULL);
    pthread_mutex_init(&mutexE, NULL);

    pthread_t thread1, thread2, thread3, thread4, thread5;
    pthread_create(&thread1, NULL, thread_function_one, NULL);
    pthread_create(&thread2, NULL, thread_function_two, NULL);
    pthread_create(&thread3, NULL, thread_function_three, NULL);
    pthread_create(&thread4, NULL, thread_function_four, NULL);
    pthread_create(&thread5, NULL, thread_function_five, NULL);

    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);
    pthread_join(thread3, NULL);
    pthread_join(thread4, NULL);
    pthread_join(thread5, NULL);

    pthread_mutex_destroy(&mutexA);
    pthread_mutex_destroy(&mutexB);
    pthread_mutex_destroy(&mutexC);
    pthread_mutex_destroy(&mutexD);
    pthread_mutex_destroy(&mutexE);

    return 0;
}

