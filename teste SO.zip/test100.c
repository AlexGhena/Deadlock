#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

pthread_mutex_t mutex1;
pthread_mutex_t mutex2;
pthread_mutex_t mutex3;
pthread_mutex_t mutex4;
pthread_mutex_t mutex5;
pthread_mutex_t mutex6;
pthread_mutex_t mutex7;
pthread_mutex_t mutex8;
pthread_mutex_t mutex9;
pthread_mutex_t mutex10;

void* thread_function_one(void* arg) {
    pthread_mutex_lock(&mutex1);
    pthread_mutex_lock(&mutex2);
    pthread_mutex_unlock(&mutex2);
    pthread_mutex_unlock(&mutex1);
    return NULL;
}

void* thread_function_two(void* arg) {
    pthread_mutex_lock(&mutex2);
    pthread_mutex_lock(&mutex3);
    pthread_mutex_unlock(&mutex3);
    pthread_mutex_unlock(&mutex2);
    return NULL;
}

void* thread_function_three(void* arg) {
    pthread_mutex_lock(&mutex3);
    pthread_mutex_lock(&mutex4);
    pthread_mutex_unlock(&mutex4);
    pthread_mutex_unlock(&mutex3);
    return NULL;
}

void* thread_function_four(void* arg) {
    pthread_mutex_lock(&mutex4);
    pthread_mutex_lock(&mutex5);
    pthread_mutex_unlock(&mutex5);
    pthread_mutex_unlock(&mutex4);
    return NULL;
}

void* thread_function_five(void* arg) {
    pthread_mutex_lock(&mutex5);
    pthread_mutex_lock(&mutex6);
    pthread_mutex_unlock(&mutex6);
    pthread_mutex_unlock(&mutex5);
    return NULL;
}

void* thread_function_six(void* arg) {
    pthread_mutex_lock(&mutex6);
    pthread_mutex_lock(&mutex7);
    pthread_mutex_unlock(&mutex7);
    pthread_mutex_unlock(&mutex6);
    return NULL;
}

void* thread_function_seven(void* arg) {
    pthread_mutex_lock(&mutex7);
    pthread_mutex_lock(&mutex8);
    pthread_mutex_unlock(&mutex8);
    pthread_mutex_unlock(&mutex7);
    return NULL;
}

void* thread_function_eight(void* arg) {
    pthread_mutex_lock(&mutex8);
    pthread_mutex_lock(&mutex1);
    pthread_mutex_unlock(&mutex1);
    pthread_mutex_unlock(&mutex8);
    return NULL;
}
void* thread_function_nine(void* arg) {
    pthread_mutex_lock(&mutex9);
    pthread_mutex_lock(&mutex1);
    pthread_mutex_unlock(&mutex1);
    pthread_mutex_unlock(&mutex9);
    return NULL;
}
void* thread_function_ten(void* arg) {
    pthread_mutex_lock(&mutex10);
    pthread_mutex_lock(&mutex1);
    pthread_mutex_unlock(&mutex1);
    pthread_mutex_unlock(&mutex10);
    return NULL;
}

int main() {
    pthread_mutex_init(&mutex1, NULL);
    pthread_mutex_init(&mutex2, NULL);
    pthread_mutex_init(&mutex3, NULL);
    pthread_mutex_init(&mutex4, NULL);
    pthread_mutex_init(&mutex5, NULL);
    pthread_mutex_init(&mutex6, NULL);
    pthread_mutex_init(&mutex7, NULL);
    pthread_mutex_init(&mutex8, NULL);
    pthread_mutex_init(&mutex9, NULL);
    pthread_mutex_init(&mutex10, NULL);

    pthread_t thread1, thread2, thread3, thread4, thread5, thread6, thread7, thread8, thread9, thread10;
    pthread_create(&thread1, NULL, thread_function_one, NULL);
    pthread_create(&thread2, NULL, thread_function_two, NULL);
    pthread_create(&thread3, NULL, thread_function_three, NULL);
    pthread_create(&thread4, NULL, thread_function_four, NULL);
    pthread_create(&thread5, NULL, thread_function_five, NULL);
    pthread_create(&thread6, NULL, thread_function_six, NULL);
    pthread_create(&thread7, NULL, thread_function_seven, NULL);
    pthread_create(&thread8, NULL, thread_function_eight, NULL);
    pthread_create(&thread9, NULL, thread_function_nine, NULL);
    pthread_create(&thread10, NULL, thread_function_ten, NULL);
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);
    pthread_join(thread3, NULL);
    pthread_join(thread4, NULL);
    pthread_join(thread5, NULL);
    pthread_join(thread6, NULL);
    pthread_join(thread7, NULL);
    pthread_join(thread8, NULL);
    pthread_join(thread9, NULL);
    pthread_join(thread10, NULL);

    pthread_mutex_destroy(&mutex1);
    pthread_mutex_destroy(&mutex2);
    pthread_mutex_destroy(&mutex3);
    pthread_mutex_destroy(&mutex4);
    pthread_mutex_destroy(&mutex5);
    pthread_mutex_destroy(&mutex6);
    pthread_mutex_destroy(&mutex7);
    pthread_mutex_destroy(&mutex8);
    pthread_mutex_destroy(&mutex9);
    pthread_mutex_destroy(&mutex10);

    return 0;
}

